"""
AgentSZZ Runner
===============
Orchestrates the Executor (and optionally Validator) agents to identify
Bug-Introducing Commits (BICs) in the Linux kernel.

Features:
  1. Cache layer: deduplicates identical tool calls (transparent to agent)
  2. Structured extraction: deterministic compression for long tool results
  3. Fix date cap: auto-caps search before= to fix commit date
"""

import json
import os
import re
import argparse
import subprocess
from datetime import datetime
from time import perf_counter

from openai import OpenAI

# Tool imports
from tools.git_show_tool import git_show, TOOL_SCHEMA as SHOW_SCHEMA
from tools.git_blame_tool import git_blame, TOOL_SCHEMA as BLAME_SCHEMA
from tools.git_log_s_tool import git_log_s, TOOL_SCHEMA as LOG_S_SCHEMA
from tools.git_log_func_tool import git_log_func, TOOL_SCHEMA as LOG_FUNC_SCHEMA
from tools.git_grep_tool import git_grep, TOOL_SCHEMA as GREP_SCHEMA

# Internal modules
import tool_cache
import structured_extract
from validator import run_validator

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

MODEL = "openai/gpt-5-mini"
BASE_URL = "https://openrouter.ai/api/v1"
MAX_EXECUTOR_TURNS = 15
MAX_VALIDATION_ROUNDS = 3
ENABLE_VALIDATOR = False
EXECUTOR_PROMPT_PATH = "prompts/executor_prompt.txt"
VALIDATOR_PROMPT_PATH = "prompts/validator_prompt.txt"
EXTRACT_CHAR_THRESHOLD = 3000

INITIAL_COMMIT = "1da177e4c3f41524e886b7f1b8a0c1fc7321cac2"


# ---------------------------------------------------------------------------
# Tool dispatch
# ---------------------------------------------------------------------------

ALL_TOOL_SCHEMAS = [SHOW_SCHEMA, BLAME_SCHEMA, LOG_S_SCHEMA, LOG_FUNC_SCHEMA, GREP_SCHEMA]

TOOL_FUNCTIONS = {
    "git_show": git_show,
    "git_blame": git_blame,
    "git_log_s": git_log_s,
    "git_log_func": git_log_func,
    "git_grep": git_grep,
}


def dispatch_tool(tool_name: str, arguments: dict, repo_path: str) -> str:
    """Execute a tool call and return the result."""
    if tool_name not in TOOL_FUNCTIONS:
        return f"ERROR: unknown tool '{tool_name}'"

    fn = TOOL_FUNCTIONS[tool_name]
    arguments["repo_path"] = repo_path

    try:
        return fn(**arguments)
    except TypeError as e:
        return f"ERROR: invalid arguments for {tool_name}: {e}"
    except Exception as e:
        return f"ERROR: {tool_name} failed: {e}"


def dispatch_tool_cached(
    tool_name: str,
    arguments: dict,
    repo_path: str,
    fix_date: str = "",
) -> tuple[str, str, bool]:
    """
    Dispatch with cache + structured extraction + date cap.
    Returns: (message_content, full_result, was_cached)
    """
    # Auto-cap 'before' to fix commit date for search tools
    if fix_date and tool_name in ("git_log_s", "git_log_func"):
        before_val = arguments.get("before", "")
        if before_val and before_val > fix_date:
            arguments["before"] = fix_date

    # Dedup check
    clean_args = {k: v for k, v in arguments.items() if k != "repo_path"}
    cached = tool_cache.lookup_by_call(tool_name, clean_args)
    if cached is not None:
        msg = _format_result(tool_name, cached)
        return msg, cached, True

    # Execute
    full_result = dispatch_tool(tool_name, arguments, repo_path)
    tool_cache.store(tool_name, clean_args, full_result)
    msg = _format_result(tool_name, full_result)
    return msg, full_result, False


def _format_result(tool_name: str, full_result: str) -> str:
    """Apply deterministic structured extraction for long results."""
    if len(full_result) <= EXTRACT_CHAR_THRESHOLD:
        return full_result

    print(f"    [Extract] Compressing {tool_name} result ({len(full_result)} chars)...")
    extracted = structured_extract.extract(tool_name, full_result)
    print(f"    [Extract] → {len(extracted)} chars")
    return extracted


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_commit_date(fix_info: str) -> str:
    """Extract ISO date from git_show output. e.g. '2023-11-26'."""
    for line in fix_info.split('\n'):
        line = line.strip()
        m = re.match(r'^Date:\s+\w+\s+(\w+)\s+(\d+)\s+[\d:]+\s+(\d{4})', line)
        if m:
            month_str, day, year = m.group(1), m.group(2), m.group(3)
            months = {
                'Jan': '01', 'Feb': '02', 'Mar': '03', 'Apr': '04',
                'May': '05', 'Jun': '06', 'Jul': '07', 'Aug': '08',
                'Sep': '09', 'Oct': '10', 'Nov': '11', 'Dec': '12',
            }
            month = months.get(month_str, '01')
            return f"{year}-{month}-{day.zfill(2)}"
    return ""


def load_prompt(path: str) -> str:
    with open(path, "r") as f:
        return f.read()


def build_timeout_hint(trace_log: list) -> str:
    """Inject a narrow hint after a real tool timeout."""
    timed_out = [e for e in trace_log if e.get("timed_out")]
    if not timed_out:
        return ""

    tool = timed_out[-1].get("tool")
    hints = {
        "git_show": "A previous git_show timed out. Retry with smaller context_lines or stat_only=True.",
        "git_blame": "A previous git_blame timed out. Retry with a smaller line range.",
        "git_log_s": "A previous git_log_s timed out. Retry with a narrower path, tighter date range, or smaller max_commits.",
        "git_log_func": "A previous git_log_func timed out. Retry with a tighter date range or smaller max_commits.",
        "git_grep": "A previous git_grep timed out. Retry with a narrower path or more specific symbol.",
    }
    return hints.get(tool, "A previous tool call timed out. Narrow the next query.")


def _extract_assistant_message(response):
    """Validate provider response before indexing into choices."""
    choices = getattr(response, "choices", None) or []
    if not choices or choices[0] is None:
        raise RuntimeError("Malformed API response: missing choices")

    message = getattr(choices[0], "message", None)
    if message is None:
        raise RuntimeError("Malformed API response: missing assistant message")

    return message


def _usage_value(obj, key: str) -> int:
    if obj is None:
        return 0
    if isinstance(obj, dict):
        value = obj.get(key, 0)
    else:
        value = getattr(obj, key, 0)
    return value or 0


def _extract_usage(response) -> dict:
    usage = getattr(response, "usage", None)
    prompt_details = getattr(usage, "prompt_tokens_details", None)
    completion_details = getattr(usage, "completion_tokens_details", None)
    return {
        "prompt_tokens": _usage_value(usage, "prompt_tokens"),
        "completion_tokens": _usage_value(usage, "completion_tokens"),
        "total_tokens": _usage_value(usage, "total_tokens"),
        "cached_tokens": _usage_value(prompt_details, "cached_tokens"),
        "reasoning_tokens": _usage_value(completion_details, "reasoning_tokens"),
    }


def _summarize_executor_stats(api_calls: list, tool_calls: list, executor_elapsed_seconds: float) -> dict:
    api_elapsed_seconds = sum(call.get("elapsed_seconds", 0.0) for call in api_calls)
    tool_elapsed_seconds = sum(call.get("elapsed_seconds", 0.0) for call in tool_calls)

    prompt_tokens = sum(call.get("usage", {}).get("prompt_tokens", 0) for call in api_calls)
    completion_tokens = sum(call.get("usage", {}).get("completion_tokens", 0) for call in api_calls)
    total_tokens = sum(call.get("usage", {}).get("total_tokens", 0) for call in api_calls)
    cached_tokens = sum(call.get("usage", {}).get("cached_tokens", 0) for call in api_calls)
    reasoning_tokens = sum(call.get("usage", {}).get("reasoning_tokens", 0) for call in api_calls)

    return {
        "executor_elapsed_seconds": round(executor_elapsed_seconds, 6),
        "api_call_count": len(api_calls),
        "api_elapsed_seconds": round(api_elapsed_seconds, 6),
        "tool_call_count": len(tool_calls),
        "tool_elapsed_seconds": round(tool_elapsed_seconds, 6),
        "other_elapsed_seconds": round(max(executor_elapsed_seconds - api_elapsed_seconds - tool_elapsed_seconds, 0.0), 6),
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": total_tokens,
        "cached_tokens": cached_tokens,
        "reasoning_tokens": reasoning_tokens,
    }


# ---------------------------------------------------------------------------
# Executor Agent
# ---------------------------------------------------------------------------

def run_executor(
    client: OpenAI,
    repo_path: str,
    fix_commit: str,
    fix_info: str,
    prior_context: str = "",
    trace_log: list = None,
) -> dict:
    """Run the Executor agent. Returns dict with bic, confidence, type, reasoning, messages."""
    if trace_log is None:
        trace_log = []

    system_prompt = load_prompt(EXECUTOR_PROMPT_PATH)
    fix_date = _extract_commit_date(fix_info)
    executor_started = perf_counter()
    api_calls = []

    # Build user message
    user_content = f"## Fix Commit\n\n{fix_info}\n"
    if fix_date:
        user_content += (
            f"\n**Fix commit date: {fix_date}**. "
            f"The BIC must be before this date. "
            f"Use this as the upper bound for any date-based searches.\n"
        )
    if prior_context:
        user_content += f"\n## Previous Investigation Context\n\n{prior_context}\n"
        user_content += "\nContinue the investigation. The previous candidate was rejected.\n"
    else:
        user_content += "\nFind the Bug-Introducing Commit (BIC) for this fix.\n"

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content},
    ]
    last_timeout_hint = ""

    # Multi-turn tool calling loop
    for turn in range(MAX_EXECUTOR_TURNS):
        timeout_hint = build_timeout_hint(trace_log)
        if timeout_hint and timeout_hint != last_timeout_hint:
            messages.append({"role": "system", "content": timeout_hint})
        last_timeout_hint = timeout_hint

        assistant_msg = None
        for api_attempt in range(3):
            print(f"    [Executor] Turn {turn+1}: calling API...")
            api_started = perf_counter()
            response = client.chat.completions.create(
                model=MODEL,
                messages=messages,
                tools=ALL_TOOL_SCHEMAS,
                tool_choice="auto",
                timeout=120,
            )
            api_elapsed = perf_counter() - api_started
            print(f"    [Executor] Turn {turn+1}: got response")

            api_entry = {
                "turn": turn + 1,
                "attempt": api_attempt + 1,
                "timestamp": datetime.now().isoformat(),
                "elapsed_seconds": round(api_elapsed, 6),
                "usage": _extract_usage(response),
                "malformed_response": False,
            }

            try:
                assistant_msg = _extract_assistant_message(response)
                api_calls.append(api_entry)
                break
            except RuntimeError as e:
                api_entry["malformed_response"] = True
                api_entry["error"] = str(e)
                api_calls.append(api_entry)
                print(f"    [Executor] Turn {turn+1}: {e} (attempt {api_attempt+1}/3)")
                if api_attempt == 2:
                    raise

        messages.append(assistant_msg.model_dump())

        if not assistant_msg.tool_calls:
            break

        for tool_call in assistant_msg.tool_calls:
            fn_name = tool_call.function.name
            fn_args = json.loads(tool_call.function.arguments)

            print(f"    [Executor] Turn {turn+1}: {fn_name}({', '.join(f'{k}={v!r}' for k,v in fn_args.items())})")

            tool_started = perf_counter()
            msg_content, full_result, was_cached = dispatch_tool_cached(
                fn_name, fn_args, repo_path, fix_date=fix_date
            )
            tool_elapsed = perf_counter() - tool_started

            trace_log.append({
                "turn": turn + 1,
                "tool": fn_name,
                "arguments": fn_args,
                "timestamp": datetime.now().isoformat(),
                "elapsed_seconds": round(tool_elapsed, 6),
                "was_cached": was_cached,
                "result_preview": full_result[:500] + "..." if len(full_result) > 500 else full_result,
                "timed_out": "timed out" in full_result.lower(),
            })

            messages.append({
                "role": "tool",
                "tool_call_id": tool_call.id,
                "content": msg_content,
            })

    # Parse result
    final_text = assistant_msg.content or ""
    result = parse_executor_result(final_text)
    result["bic"] = normalize_executor_bic(result.get("bic", ""), repo_path)

    result["messages"] = messages
    result["api_calls"] = api_calls
    result["stats"] = _summarize_executor_stats(
        api_calls,
        trace_log,
        perf_counter() - executor_started,
    )
    return result


def parse_executor_result(text: str) -> dict:
    """Parse the Executor's final output."""
    result = {
        "bic": "",
        "confidence": "low",
        "type": "unknown",
        "reasoning": "",
        "raw_output": text,
    }

    match = (
        re.search(r"<r>(.*?)</r>", text, re.DOTALL) or
        re.search(r"<response>(.*?)</response>", text, re.DOTALL)
    )
    block = match.group(1) if match else text

    for line in block.strip().split("\n"):
        line = line.strip()
        line = re.sub(r"^[-*\s]*", "", line)
        line = re.sub(r"\*\*", "", line)

        if re.match(r"^BIC:", line, re.IGNORECASE):
            result["bic"] = re.sub(r"^BIC:\s*", "", line, flags=re.IGNORECASE).strip()
        elif re.match(r"^confidence:", line, re.IGNORECASE):
            result["confidence"] = re.sub(r"^confidence:\s*", "", line, flags=re.IGNORECASE).strip()
        elif re.match(r"^type:", line, re.IGNORECASE):
            result["type"] = re.sub(r"^type:\s*", "", line, flags=re.IGNORECASE).strip()
        elif re.match(r"^reasoning:", line, re.IGNORECASE):
            result["reasoning"] = re.sub(r"^reasoning:\s*", "", line, flags=re.IGNORECASE).strip()

    return result


def _sanitize_commitish(text: str) -> str:
    if not text:
        return ""
    return re.sub(r"[^0-9a-fA-F]", "", text).lower()[:40]


def _rev_parse_commit(repo_path: str, commitish: str) -> str:
    if not commitish:
        return ""
    try:
        proc = subprocess.run(
            ["git", "-C", repo_path, "rev-parse", "--verify", f"{commitish}^{{commit}}"],
            capture_output=True, text=True, check=False,
        )
    except Exception:
        return ""
    return proc.stdout.strip() if proc.returncode == 0 else ""


def normalize_executor_bic(raw_bic: str, repo_path: str) -> str:
    """Clean and resolve the Executor's BIC hash."""
    cleaned = _sanitize_commitish(raw_bic)
    if not cleaned:
        return ""

    resolved = _rev_parse_commit(repo_path, cleaned)
    if resolved:
        return resolved

    for prefix_len in (12, 10, 8, 7):
        if len(cleaned) > prefix_len:
            resolved = _rev_parse_commit(repo_path, cleaned[:prefix_len])
            if resolved:
                return resolved

    return cleaned


# ---------------------------------------------------------------------------
# Main orchestration
# ---------------------------------------------------------------------------

def run_agentszz(
    repo_path: str,
    fix_commit: str,
    output_dir: str = "./output",
    commit_subdir: str = "",
) -> dict:
    """Run the full AgentSZZ pipeline."""
    tool_cache.clear()
    pipeline_started = perf_counter()

    client = OpenAI(
        base_url=BASE_URL,
        api_key=os.environ.get("OPENROUTER_API_KEY", ""),
    )
    os.makedirs(output_dir, exist_ok=True)

    print(f"[*] Analyzing fix commit: {fix_commit}")
    fix_info = git_show(fix_commit, repo_path)
    if fix_info.startswith("ERROR:"):
        print(f"[!] Failed to get fix commit info: {fix_info}")
        return {"error": fix_info}

    all_traces = []
    all_prompts = []
    prior_context = ""
    final_result = None

    for round_num in range(1, MAX_VALIDATION_ROUNDS + 1):
        print(f"\n{'='*60}")
        print(f"[*] Round {round_num}: Running Executor")
        print(f"{'='*60}")

        trace_log = []
        executor_result = run_executor(
            client, repo_path, fix_commit, fix_info,
            prior_context=prior_context,
            trace_log=trace_log,
        )

        all_traces.append({
            "round": round_num,
            "agent": "executor",
            "api_calls": executor_result.get("api_calls", []),
            "tool_calls": trace_log,
            "stats": executor_result.get("stats", {}),
            "result": {k: executor_result.get(k) for k in ("bic", "confidence", "type", "reasoning")},
        })
        all_prompts.append({
            "round": round_num,
            "agent": "executor",
            "messages": serialize_messages(executor_result.get("messages", [])),
        })

        candidate = executor_result.get("bic", "")
        print(f"[*] Executor candidate: {candidate}")
        print(f"    Confidence: {executor_result.get('confidence')}")
        print(f"    Type: {executor_result.get('type')}")
        print(f"    Reasoning: {executor_result.get('reasoning')}")

        if not candidate:
            print("[!] Executor did not provide a candidate BIC")
            final_result = executor_result
            break

        if not ENABLE_VALIDATOR:
            print("\n[*] Validator disabled; using Executor result directly")
            final_result = executor_result
            break

        # Run Validator
        print(f"\n[*] Round {round_num}: Running Validator")
        validator_prompt = load_prompt(VALIDATOR_PROMPT_PATH)
        validator_result = run_validator(
            client, MODEL, repo_path, fix_info,
            executor_result, trace_log, validator_prompt,
        )

        all_traces.append({
            "round": round_num,
            "agent": "validator",
            "result": {k: validator_result.get(k) for k in ("decision", "reason", "details")},
        })

        print(f"[*] Validator decision: {validator_result.get('decision')}")
        if validator_result.get("decision") == "ACCEPT":
            print(f"\n[✓] BIC accepted: {candidate}")
            final_result = executor_result
            final_result["validation"] = validator_result
            break
        else:
            prior_context = build_retry_context(executor_result, validator_result, trace_log)

    if final_result is None:
        final_result = executor_result

    final_result["metrics"] = {
        "case_elapsed_seconds": round(perf_counter() - pipeline_started, 6),
        "api_elapsed_seconds": round(
            sum(t.get("stats", {}).get("api_elapsed_seconds", 0.0) for t in all_traces),
            6,
        ),
        "tool_elapsed_seconds": round(
            sum(t.get("stats", {}).get("tool_elapsed_seconds", 0.0) for t in all_traces),
            6,
        ),
        "other_elapsed_seconds": round(
            max(
                perf_counter() - pipeline_started
                - sum(t.get("stats", {}).get("api_elapsed_seconds", 0.0) for t in all_traces)
                - sum(t.get("stats", {}).get("tool_elapsed_seconds", 0.0) for t in all_traces),
                0.0,
            ),
            6,
        ),
        "api_call_count": sum(t.get("stats", {}).get("api_call_count", 0) for t in all_traces),
        "tool_call_count": sum(t.get("stats", {}).get("tool_call_count", 0) for t in all_traces),
        "prompt_tokens": sum(t.get("stats", {}).get("prompt_tokens", 0) for t in all_traces),
        "completion_tokens": sum(t.get("stats", {}).get("completion_tokens", 0) for t in all_traces),
        "total_tokens": sum(t.get("stats", {}).get("total_tokens", 0) for t in all_traces),
        "cached_tokens": sum(t.get("stats", {}).get("cached_tokens", 0) for t in all_traces),
        "reasoning_tokens": sum(t.get("stats", {}).get("reasoning_tokens", 0) for t in all_traces),
    }

    save_outputs(output_dir, fix_commit, final_result, all_traces, all_prompts, commit_subdir)
    return final_result


def build_retry_context(executor_result, validator_result, trace_log):
    parts = [
        "## Previous Investigation Summary",
        f"Candidate BIC {executor_result.get('bic', '?')} was REJECTED.",
        f"Rejection reason: {validator_result.get('reason', '?')}",
        f"Details: {validator_result.get('details', '?')}",
    ]
    if validator_result.get("compressed_context"):
        parts.append(f"\n{validator_result['compressed_context']}")
    parts.append("\n## Tool Calls Performed")
    for entry in trace_log:
        args_str = ", ".join(f"{k}={v!r}" for k, v in entry["arguments"].items())
        parts.append(f"- {entry['tool']}({args_str})")
    parts.append("\nDo NOT repeat the same tool calls. Investigate deeper.")
    return "\n".join(parts)


def serialize_messages(messages: list) -> list:
    serialized = []
    for msg in messages:
        if isinstance(msg, dict):
            serialized.append(msg)
        else:
            try:
                serialized.append(msg.model_dump() if hasattr(msg, 'model_dump') else str(msg))
            except Exception:
                serialized.append(str(msg))
    return serialized


def save_outputs(output_dir, fix_commit, final_result, all_traces, all_prompts, commit_subdir=""):
    commit_dir = os.path.join(output_dir, commit_subdir.strip() or fix_commit[:12])
    os.makedirs(commit_dir, exist_ok=True)

    for name, data in [("trace", all_traces), ("prompts", all_prompts)]:
        path = os.path.join(commit_dir, f"{name}.json")
        with open(path, "w") as f:
            json.dump(data, f, indent=2, default=str)
        print(f"[*] {name.capitalize()} saved: {path}")

    result_path = os.path.join(commit_dir, "result.json")
    with open(result_path, "w") as f:
        json.dump({
            "fix_commit": fix_commit,
            "bic": final_result.get("bic", ""),
            "confidence": final_result.get("confidence", ""),
            "type": final_result.get("type", ""),
            "reasoning": final_result.get("reasoning", ""),
            "metrics": final_result.get("metrics", {}),
            "validation": final_result.get("validation", {}),
            "timestamp": datetime.now().isoformat(),
        }, f, indent=2, default=str)
    print(f"[*] Result saved: {result_path}")


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="AgentSZZ: Find Bug-Introducing Commits")
    parser.add_argument("--repo", required=True, help="Path to Linux kernel git repository")
    parser.add_argument("--fix-commit", required=True, help="Fix commit hash")
    parser.add_argument("--output-dir", default="./output", help="Output directory")
    parser.add_argument("--model", default=MODEL, help=f"Model (default: {MODEL})")
    parser.add_argument("--base-url", default=BASE_URL, help=f"API base URL")

    args = parser.parse_args()
    MODEL = args.model
    BASE_URL = args.base_url

    result = run_agentszz(args.repo, args.fix_commit, args.output_dir)
    if result.get("bic"):
        print(f"\n{'='*60}")
        print(f"FINAL BIC: {result['bic']}")
        print(f"{'='*60}")
