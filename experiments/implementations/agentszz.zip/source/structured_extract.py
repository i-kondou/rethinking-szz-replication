"""
Structured Extractors
=====================
Deterministic extraction of hard facts from git tool outputs.
No LLM calls. Preserves commit hashes, line numbers, function names,
and key changed lines — drops verbose context and redundant diff body.

Each extractor takes raw tool output and returns a compressed string
that preserves all facts needed for BIC identification.
"""

import re
from collections import OrderedDict


# ---------------------------------------------------------------------------
# git_show extractor
# ---------------------------------------------------------------------------

def extract_git_show(raw: str, max_diff_lines: int = 80) -> str:
    """
    Extract structured facts from git_show output.

    Keeps:
      - Full commit header (hash, date, subject, message)
      - Diff stat (files changed summary)
      - Hunk headers (@@ lines with function context)
      - Added/removed lines (+ / - lines)
    Drops:
      - Context lines (lines starting with space in diff)
      - Truncates if too many diff lines
    """
    if raw.startswith("ERROR:"):
        return raw

    lines = raw.split("\n")

    # Split into header and diff sections
    diff_start = None
    for i, line in enumerate(lines):
        if line.startswith("diff --git"):
            diff_start = i
            break

    if diff_start is None:
        # No diff (e.g., merge commit or stat_only) — return as-is
        return raw

    header = "\n".join(lines[:diff_start])

    # Process diff: keep only structural lines
    diff_lines = lines[diff_start:]
    kept = []
    total_hunks = 0
    dropped_context = 0

    for line in diff_lines:
        if (line.startswith("diff --git") or
            line.startswith("---") or
            line.startswith("+++") or
            line.startswith("index ")):
            kept.append(line)
        elif line.startswith("@@"):
            kept.append(line)
            total_hunks += 1
        elif line.startswith("+") or line.startswith("-"):
            kept.append(line)
        else:
            dropped_context += 1

    # Truncate if still too long
    if len(kept) > max_diff_lines:
        half = max_diff_lines // 2
        truncated = (
            kept[:half]
            + [f"\n... [{len(kept) - max_diff_lines} diff lines omitted, {total_hunks} hunks total] ...\n"]
            + kept[-half:]
        )
        kept = truncated

    result = header + "\n\n"
    if dropped_context > 0:
        result += f"[diff: context lines stripped, {dropped_context} lines dropped]\n"
    result += "\n".join(kept)

    return result


# ---------------------------------------------------------------------------
# git_blame extractor
# ---------------------------------------------------------------------------

def extract_git_blame(raw: str, max_lines: int = 150) -> str:
    """
    Extract structured facts from git_blame output.

    Keeps:
      - All L<n>: <hash> | <code> lines (these are the core evidence)
      - Unique commit summary at the top
    Truncates if over max_lines (keeps head + tail).
    """
    if raw.startswith("ERROR:"):
        return raw

    lines = raw.strip().split("\n")

    # Extract unique commits from blame output
    commits = OrderedDict()
    for line in lines:
        m = re.match(r"L(\d+):\s+([0-9a-f]+)\s+\|", line)
        if m:
            commit = m.group(2)
            if commit not in commits:
                commits[commit] = 0
            commits[commit] += 1

    if len(lines) <= max_lines:
        # Short enough — prepend commit summary, return all
        summary = f"[{len(lines)} lines, {len(commits)} unique commits: {', '.join(commits.keys())}]\n"
        return summary + raw

    # Truncate: head + tail
    half = max_lines // 2
    summary = f"[{len(lines)} lines total, {len(commits)} unique commits: {', '.join(commits.keys())}]\n"
    truncated = (
        "\n".join(lines[:half])
        + f"\n\n... [{len(lines) - max_lines} lines omitted] ...\n\n"
        + "\n".join(lines[-half:])
    )
    return summary + truncated


# ---------------------------------------------------------------------------
# git_log_s extractor
# ---------------------------------------------------------------------------

def extract_git_log_s(raw: str, max_entries: int = 30) -> str:
    """
    Extract structured facts from git_log_s (pickaxe) output.

    Format is typically: "hash subject" per line.
    Keeps first max_entries, drops the rest with count.
    """
    if raw.startswith("ERROR:"):
        return raw

    lines = [l for l in raw.strip().split("\n") if l.strip()]

    if len(lines) <= max_entries:
        return f"[{len(lines)} commits found]\n" + raw

    kept = lines[:max_entries]
    return (
        f"[{len(lines)} commits found, showing first {max_entries}]\n"
        + "\n".join(kept)
        + f"\n... [{len(lines) - max_entries} more commits omitted]"
    )


# ---------------------------------------------------------------------------
# git_grep extractor
# ---------------------------------------------------------------------------

def extract_git_grep(raw: str, max_matches: int = 40) -> str:
    """
    Extract structured facts from git_grep output.

    Format: "file:line:match" per line.
    Groups by file, keeps up to max_matches total, deduplicates.
    """
    if raw.startswith("ERROR:"):
        return raw

    lines = [l for l in raw.strip().split("\n") if l.strip()]

    if len(lines) <= max_matches:
        return f"[{len(lines)} matches]\n" + raw

    # Group by file for better overview
    by_file = OrderedDict()
    for line in lines:
        parts = line.split(":", 2)
        fname = parts[0] if len(parts) >= 2 else "unknown"
        if fname not in by_file:
            by_file[fname] = []
        by_file[fname].append(line)

    # Build summary: file list + first N matches
    file_summary = ", ".join(f"{f} ({len(matches)})" for f, matches in by_file.items())
    kept = lines[:max_matches]

    return (
        f"[{len(lines)} matches across {len(by_file)} files: {file_summary}]\n"
        + "\n".join(kept)
        + f"\n... [{len(lines) - max_matches} more matches omitted]"
    )


# ---------------------------------------------------------------------------
# git_log_func extractor
# ---------------------------------------------------------------------------

def extract_git_log_func(raw: str, max_entries: int = 30) -> str:
    """
    Extract structured facts from git_log_func output.
    Similar to git_log_s — commit history for a specific function.
    """
    if raw.startswith("ERROR:"):
        return raw

    lines = [l for l in raw.strip().split("\n") if l.strip()]

    if len(lines) <= max_entries:
        return f"[{len(lines)} commits]\n" + raw

    kept = lines[:max_entries]
    return (
        f"[{len(lines)} commits found, showing first {max_entries}]\n"
        + "\n".join(kept)
        + f"\n... [{len(lines) - max_entries} more commits omitted]"
    )


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

EXTRACTORS = {
    "git_show": extract_git_show,
    "git_blame": extract_git_blame,
    "git_log_s": extract_git_log_s,
    "git_grep": extract_git_grep,
    "git_log_func": extract_git_log_func,
}


def extract(tool_name: str, raw: str) -> str:
    """
    Apply the appropriate extractor for a tool.
    Falls back to raw output if no extractor found.
    """
    extractor = EXTRACTORS.get(tool_name)
    if extractor is None:
        return raw
    return extractor(raw)