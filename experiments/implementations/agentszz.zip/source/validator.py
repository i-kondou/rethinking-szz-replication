"""
AgentSZZ Validator Agent
========================
Validates Executor's BIC candidate by reviewing the evidence.
"""

import re
from openai import OpenAI
from tools.git_show_tool import git_show


def run_validator(
    client: OpenAI,
    model: str,
    repo_path: str,
    fix_info: str,
    executor_result: dict,
    trace_log: list,
    system_prompt: str,
) -> dict:
    """
    Run the Validator agent.

    Args:
        client: OpenAI client
        model: Model name
        repo_path: Path to git repository
        fix_info: git_show output of fix commit
        executor_result: Executor's result dict
        trace_log: Executor's tool call trace
        system_prompt: Validator system prompt

    Returns:
        dict with keys: decision, reason, details, compressed_context
    """
    # Fetch the candidate BIC's git_show
    candidate_bic = executor_result.get("bic", "")
    if candidate_bic:
        bic_info = git_show(candidate_bic, repo_path)
    else:
        bic_info = "(No candidate BIC provided)"

    # Build tool call summary
    tool_summary = build_tool_summary(trace_log)

    user_content = f"""## Fix Commit

{fix_info}

## Executor's Candidate BIC

Commit: {candidate_bic}
Confidence: {executor_result.get('confidence', 'unknown')}
Type: {executor_result.get('type', 'unknown')}
Reasoning: {executor_result.get('reasoning', 'none')}

## Candidate BIC Details (git_show)

{bic_info}

## Executor's Investigation Trace

{tool_summary}

Validate whether this BIC identification is correct.
"""

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content},
    ]

    print(f"    [Validator] Calling API...")
    response = client.chat.completions.create(
        model=model,
        messages=messages,
        timeout=120,
    )
    print(f"    [Validator] Got response")

    final_text = response.choices[0].message.content or ""
    return parse_validator_result(final_text)


def parse_validator_result(text: str) -> dict:
    """Parse the Validator's output. Handles multiple tag formats."""
    result = {
        "decision": "REJECT",
        "reason": "parse_error",
        "details": "",
        "compressed_context": "",
        "raw_output": text,
    }

    # Match any XML-like tag block
    match = re.search(r"<(\w+)>(.*?)</\1>", text, re.DOTALL)
    block = match.group(2) if match else text

    for line in block.strip().split("\n"):
        line = line.strip()
        line = re.sub(r"^[-*\s]*", "", line)
        line = re.sub(r"\*\*", "", line)

        if re.match(r"^decision:", line, re.IGNORECASE):
            result["decision"] = re.sub(r"^decision:\s*", "", line, flags=re.IGNORECASE).strip()
        elif re.match(r"^reason:", line, re.IGNORECASE):
            result["reason"] = re.sub(r"^reason:\s*", "", line, flags=re.IGNORECASE).strip()
        elif re.match(r"^details:", line, re.IGNORECASE):
            result["details"] = re.sub(r"^details:\s*", "", line, flags=re.IGNORECASE).strip()
        elif re.match(r"^compressed_context:", line, re.IGNORECASE):
            result["compressed_context"] = re.sub(r"^compressed_context:\s*", "", line, flags=re.IGNORECASE).strip()

    # If we found "ACCEPT" anywhere and no proper tag, try to detect it
    if result["decision"] == "REJECT" and "ACCEPT" in text.upper() and not match:
        result["decision"] = "ACCEPT"
        result["reason"] = "validation_passed"

    return result


def build_tool_summary(trace_log: list) -> str:
    """Build a readable summary of tool calls for the Validator."""
    if not trace_log:
        return "(no tool calls recorded)"

    lines = []
    for entry in trace_log:
        args_str = ", ".join(f"{k}={v!r}" for k, v in entry["arguments"].items())
        lines.append(f"Turn {entry['turn']}: {entry['tool']}({args_str})")
        # Include short result preview
        preview = entry.get("result_preview", "")
        if preview:
            preview_lines = preview.split("\n")[:5]
            for pl in preview_lines:
                lines.append(f"  → {pl}")
            if len(preview.split("\n")) > 5:
                lines.append("  → ...")
        lines.append("")

    return "\n".join(lines)