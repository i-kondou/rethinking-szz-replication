"""
Tool Result Cache
=================
Stores full tool outputs in memory, returns LLM-compressed summaries
to the conversation, and provides a recall_cache tool for the agent
to retrieve full results on demand.
"""

import json
import hashlib
from typing import Optional

# ---------------------------------------------------------------------------
# Cache storage  (keyed by canonical hash of tool_name + sorted args)
# ---------------------------------------------------------------------------

_cache: dict[str, dict] = {}


def _make_key(tool_name: str, arguments: dict) -> str:
    """Deterministic cache key from tool name + arguments."""
    canonical = json.dumps(
        {"tool": tool_name, "args": arguments},
        sort_keys=True,
        ensure_ascii=False,
    )
    return hashlib.sha256(canonical.encode()).hexdigest()[:16]


def store(tool_name: str, arguments: dict, full_result: str) -> str:
    """Store a full tool result. Returns the cache key."""
    key = _make_key(tool_name, arguments)
    _cache[key] = {
        "tool": tool_name,
        "arguments": arguments,
        "full_result": full_result,
    }
    return key


def lookup(cache_key: str) -> Optional[str]:
    """Retrieve full result by cache key. Returns None if miss."""
    entry = _cache.get(cache_key)
    return entry["full_result"] if entry else None


def lookup_by_call(tool_name: str, arguments: dict) -> Optional[str]:
    """Check if this exact call was cached. Returns full result or None."""
    key = _make_key(tool_name, arguments)
    return lookup(key)


def list_keys() -> list[dict]:
    """List all cached entries (for debugging / the recall tool)."""
    return [
        {"key": k, "tool": v["tool"], "arguments": v["arguments"]}
        for k, v in _cache.items()
    ]


def clear():
    """Reset cache (between samples)."""
    _cache.clear()


# ---------------------------------------------------------------------------
# LLM Summarizer
# ---------------------------------------------------------------------------

SUMMARIZER_SYSTEM = """You are a concise summarizer for git tool outputs in a bug-tracing investigation.

Given:
- tool_name: which git tool was called
- arguments: the arguments passed
- full_result: the complete output

Produce a SHORT summary (3-5 sentences max) structured as:
1. **Why**: One sentence on what this call was checking.
2. **Found**: One sentence on the key finding.
3. **Evidence**: 1-2 lines of the most critical evidence (exact commit hashes, line numbers, function names). Keep these extremely short.

If the result is an error, just say what failed and why.

Reply with ONLY the summary text, no extra formatting."""


def summarize_tool_result(
    client,
    model: str,
    tool_name: str,
    arguments: dict,
    full_result: str,
    max_result_chars: int = 8000,
) -> str:
    """
    Use LLM to compress a tool result into a short summary.

    Args:
        client: OpenAI client
        model: model name
        tool_name: name of the tool
        arguments: tool arguments
        full_result: full tool output
        max_result_chars: truncate input to summarizer to control cost

    Returns:
        Compressed summary string
    """
    # Truncate very long results before sending to summarizer
    truncated = full_result
    if len(full_result) > max_result_chars:
        half = max_result_chars // 2
        truncated = (
            full_result[:half]
            + f"\n\n... [{len(full_result) - max_result_chars} chars omitted] ...\n\n"
            + full_result[-half:]
        )

    user_msg = (
        f"tool_name: {tool_name}\n"
        f"arguments: {json.dumps(arguments)}\n"
        f"full_result:\n{truncated}"
    )

    try:
        resp = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": SUMMARIZER_SYSTEM},
                {"role": "user", "content": user_msg},
            ],
            max_tokens=300,
            temperature=0,
            timeout=30,
        )
        summary = resp.choices[0].message.content or "(summary generation failed)"
    except Exception as e:
        # Fallback: deterministic truncation
        summary = (
            f"[Summarizer error: {e}]\n"
            f"Tool: {tool_name}, Args: {json.dumps(arguments)}\n"
            f"Result preview: {full_result[:300]}..."
        )

    return summary


# ---------------------------------------------------------------------------
# Recall Cache Tool Schema  (OpenAI function-calling format)
# ---------------------------------------------------------------------------

RECALL_TOOL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "recall_cache",
        "description": (
            "Retrieve the FULL output of a previous tool call from cache. "
            "Use this when you need to re-examine details from a tool result "
            "you already received a summary of. Provide the cache_key that "
            "was shown in the summary header."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "cache_key": {
                    "type": "string",
                    "description": "The cache key shown in [cache_key=xxx] of a previous tool summary.",
                },
            },
            "required": ["cache_key"],
        },
    },
}


def recall_cache(cache_key: str, **kwargs) -> str:
    """Handler for the recall_cache tool."""
    result = lookup(cache_key)
    if result is None:
        return f"ERROR: cache key '{cache_key}' not found. Available keys: {[e['key'] for e in list_keys()]}"
    return result