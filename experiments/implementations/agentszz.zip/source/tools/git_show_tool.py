"""
git_show tool for AgentSZZ
==========================
Show commit details with trailers and author info automatically filtered.

★ CHANGED: Added file_filter parameter to show diff for a single file only.
  This avoids truncation/compression issues on large multi-file commits.
"""

import subprocess
import re
from typing import Optional


TRAILER_PATTERN = re.compile(
    r"^\s*("
    r"Signed-off-by|Fixes|Reported-by|Reviewed-by|Acked-by|"
    r"Cc|Link|Closes|Tested-by|Co-developed-by|Suggested-by|"
    r"Reported-and-tested-by|Reviewed-and-tested-by|"
    r"Author|Message-Id|Message-ID"
    r"):\s.*$",
    re.MULTILINE,
)


def _run_git(args: list[str], repo_path: str, max_output_lines: int = 200) -> str:
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            return f"ERROR: {result.stderr.strip()}"

        lines = result.stdout.strip().split("\n")
        if len(lines) > max_output_lines:
            truncated = lines[:max_output_lines]
            truncated.append(f"\n... [truncated: {max_output_lines}/{len(lines)} lines]")
            return "\n".join(truncated)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        return "ERROR: command timed out (30s)"
    except Exception as e:
        return f"ERROR: {str(e)}"


def _filter_trailers(text: str) -> str:
    text = TRAILER_PATTERN.sub("", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def git_show(
    commit: str,
    repo_path: str,
    context_lines: int = 3,
    stat_only: bool = False,
    file_filter: str = None,          # ★ NEW parameter
) -> str:
    """
    Show commit date, filtered message, and diff.

    Args:
        commit:        Commit hash (full or short).
        repo_path:     Path to the git repository.
        context_lines: Number of diff context lines (default 3).
        stat_only:     If True, show only diffstat instead of full diff.
        file_filter:   If set, show diff only for this file path.
                       Use for large multi-file commits to avoid truncation.
    """
    # Metadata: date + subject + body (no author)
    meta_args = [
        "log", "-1",
        "--format=commit %H\nDate: %ad\n\n%s\n\n%b",
        "--date=format:%a %b %d %H:%M:%S %Y %z",
        commit,
    ]
    meta = _run_git(meta_args, repo_path)
    if meta.startswith("ERROR:"):
        return meta

    meta = _filter_trailers(meta)

    # Diff
    if stat_only:
        diff_args = ["diff-tree", "--stat", "--no-commit-id", "-r", commit]
        # ★ file_filter applies to stat too
        if file_filter:
            diff_args.extend(["--", file_filter])
    else:
        diff_args = [
            "diff-tree", "-p", "--no-commit-id",
            f"-U{context_lines}", "-r", commit,
        ]
        # ★ Append file_filter as pathspec after "--"
        if file_filter:
            diff_args.extend(["--", file_filter])

    diff = _run_git(diff_args, repo_path)
    if diff.startswith("ERROR:"):
        return f"{meta}\n\n[diff error: {diff}]"

    # ★ If file_filter was used but produced empty diff, note it
    if file_filter and not diff.strip():
        return (
            f"{meta}\n\n"
            f"[no changes to '{file_filter}' in this commit — "
            f"the file may have been at a different path in this older commit. "
            f"Try git_show without file_filter, or skip this and "
            f"git_blame at this_commit~1 to continue tracing.]"
        )

    return f"{meta}\n\n{diff}"


# ★ UPDATED: Tool schema now includes file_filter
TOOL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "git_show",
        "description": (
            "Show a commit's date, message (trailers filtered), and diff. "
            "Use file_filter to see only one file's diff in large multi-file commits — "
            "this avoids truncation and lets you see the full before/after changes for that file."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "commit": {
                    "type": "string",
                    "description": "Commit hash (full or short)",
                },
                "context_lines": {
                    "type": "integer",
                    "description": "Diff context lines (default 3)",
                    "default": 3,
                },
                "stat_only": {
                    "type": "boolean",
                    "description": "Show only diffstat, not full diff",
                    "default": False,
                },
                "file_filter": {
                    "type": "string",
                    "description": (
                        "Only show diff for this file path. Use when the commit touches "
                        "many files but you only need one file's changes."
                    ),
                },
            },
            "required": ["commit"],
        },
    },
}


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 3:
        print("Usage: python git_show_tool.py <repo_path> <commit_hash> [file_filter]")
        print("Example: python git_show_tool.py /path/to/linux af1e0a7d39f9")
        print("Example: python git_show_tool.py /path/to/linux af1e0a7d39f9 drivers/gpu/drm/i915/intel_dp.c")
        sys.exit(1)

    repo = sys.argv[1]
    commit = sys.argv[2]
    ff = sys.argv[3] if len(sys.argv) > 3 else None

    print(git_show(commit, repo, file_filter=ff))