"""
git_log_func tool for AgentSZZ
================================
Track the change history of a specific function body using git log -L.
Shows every commit that modified the function, with the diff.
"""

import subprocess
import re
from typing import Optional


TRAILER_PATTERN = re.compile(
    r"^\s*("
    r"Signed-off-by|Fixes|Reported-by|Reviewed-by|Acked-by|"
    r"Cc|Link|Closes|Tested-by|Co-developed-by|Suggested-by|"
    r"Reported-and-tested-by|Reviewed-and-tested-by|"
    r"Author|Message-Id|Message-ID"
    r"):\s.*$",
    re.MULTILINE,
)


def _run_git(args: list[str], repo_path: str, max_output_lines: int = 300) -> str:
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            return f"ERROR: {result.stderr.strip()}"

        lines = result.stdout.strip().split("\n")
        if len(lines) > max_output_lines:
            truncated = lines[:max_output_lines]
            truncated.append(f"\n... [truncated: {max_output_lines}/{len(lines)} lines]")
            return "\n".join(truncated)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        return "ERROR: command timed out (60s)"
    except Exception as e:
        return f"ERROR: {str(e)}"


def _filter_trailers(text: str) -> str:
    text = TRAILER_PATTERN.sub("", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def git_log_func(
    function_name: str,
    file_path: str,
    repo_path: str,
    after: Optional[str] = None,
    before: Optional[str] = None,
    max_commits: int = 10,
) -> str:
    """
    Track the change history of a function body using git log -L.
    Shows every commit that modified the function, with the diff.

    Args:
        function_name: Name of the function to track.
        file_path:     File path relative to repo root.
        repo_path:     Path to the git repository.
        after:         Only commits after this date (e.g., "2022-01-01").
        before:        Only commits before this date (e.g., "2024-01-01").
        max_commits:   Max number of commits to return (default 10).
    """
    args = [
        "log",
        f"-L:{function_name}:{file_path}",
        f"-n{max_commits}",
        "--format=commit %H%nDate: %ad%n%n    %s%n",
        "--date=format:%a %b %d %H:%M:%S %Y %z",
    ]

    if after:
        args += [f"--after={after}"]
    if before:
        args += [f"--before={before}"]

    raw = _run_git(args, repo_path)
    if raw.startswith("ERROR:"):
        return raw

    if not raw.strip():
        return f"No commits found modifying function '{function_name}' in {file_path}"

    return _filter_trailers(raw)


# Tool schema for LLM function calling
TOOL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "git_log_func",
        "description": (
            "Track the change history of a function body (git log -L). "
            "Shows every commit that modified the function with its diff. "
            "Use when you know a specific function was changed but need to "
            "find which commit altered its behavior."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "function_name": {
                    "type": "string",
                    "description": "Name of the function to track",
                },
                "file_path": {
                    "type": "string",
                    "description": "File path relative to repo root",
                },
                "after": {
                    "type": "string",
                    "description": "Only commits after this date (e.g., '2022-01-01')",
                },
                "before": {
                    "type": "string",
                    "description": "Only commits before this date (e.g., '2024-01-01')",
                },
                "max_commits": {
                    "type": "integer",
                    "description": "Max commits to return (default 10)",
                    "default": 10,
                },
            },
            "required": ["function_name", "file_path"],
        },
    },
}


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="git log -L function history tool for AgentSZZ")
    parser.add_argument("repo_path", help="Path to git repository")
    parser.add_argument("function_name", help="Function name to track")
    parser.add_argument("file_path", help="File path relative to repo root")
    parser.add_argument("--after", default=None, help="Only commits after date")
    parser.add_argument("--before", default=None, help="Only commits before date")
    parser.add_argument("-n", "--max-commits", type=int, default=10, help="Max commits (default 10)")

    args = parser.parse_args()
    print(git_log_func(args.function_name, args.file_path, args.repo_path,
                       args.after, args.before, args.max_commits))