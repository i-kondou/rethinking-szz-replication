"""Raw tool implementations for ablation C3 (no compression/formatting)."""
import subprocess


def _raw_git(args, repo_path, timeout=60):
    try:
        r = subprocess.run(
            ["git"] + args, cwd=repo_path,
            capture_output=True, text=True, timeout=timeout,
        )
        if r.returncode != 0:
            return f"ERROR: {r.stderr.strip()}"
        return r.stdout
    except subprocess.TimeoutExpired:
        return f"ERROR: timed out ({timeout}s)"
    except Exception as e:
        return f"ERROR: {e}"


def git_show(commit, repo_path, context_lines=3, stat_only=False, file_filter=None):
    if stat_only:
        args = ["show", "--stat", commit]
    else:
        args = ["show", f"-U{context_lines}", commit]
    if file_filter:
        args.extend(["--", file_filter])
    return _raw_git(args, repo_path)


def git_blame(file_path, repo_path, commit="HEAD", line_start=None, line_end=None):
    args = ["blame"]
    if line_start and line_end:
        args += [f"-L{line_start},{line_end}"]
    elif line_start:
        args += [f"-L{line_start},{line_start}"]
    args += [commit, "--", file_path]
    return _raw_git(args, repo_path)


def git_log_s(search_string, repo_path, path=None, after=None, before=None, max_commits=20):
    args = ["log", f"-S{search_string}", f"-n{max_commits}"]
    if after:
        args += [f"--after={after}"]
    if before:
        args += [f"--before={before}"]
    if path:
        args += ["--", path]
    return _raw_git(args, repo_path)


def git_log_func(function_name, file_path, repo_path, after=None, before=None, max_commits=10):
    args = ["log", f"-L:{function_name}:{file_path}", f"-n{max_commits}"]
    if after:
        args += [f"--after={after}"]
    if before:
        args += [f"--before={before}"]
    return _raw_git(args, repo_path)


def git_grep(search_string, repo_path, commit="HEAD", path=None):
    args = ["grep", "-n", search_string, commit]
    if path:
        args += ["--", path]
    try:
        r = subprocess.run(
            ["git"] + args, cwd=repo_path,
            capture_output=True, text=True, timeout=30,
        )
        if r.returncode == 1 and not r.stderr.strip():
            return f"No matches for '{search_string}'"
        if r.returncode not in (0, 1):
            return f"ERROR: {r.stderr.strip()}"
        return r.stdout
    except subprocess.TimeoutExpired:
        return "ERROR: timed out (30s)"
    except Exception as e:
        return f"ERROR: {e}"
