"""
Bare tool baseline: single run_git tool, agent writes raw git commands.
=======================================================================
No wrapping, no parsing, no formatting, no truncation.
Agent has full control over what git command to run.
"""
import subprocess


def run_git(command: str, repo_path: str) -> str:
    """Execute an arbitrary git command in the repo."""
    args = command.strip().split()
    try:
        r = subprocess.run(
            ["git"] + args, cwd=repo_path,
            capture_output=True, text=True, timeout=120,
        )
        out = r.stdout
        if r.returncode != 0:
            out += f"\nSTDERR: {r.stderr.strip()}" if r.stderr.strip() else ""
            if not out.strip():
                return f"ERROR: exit code {r.returncode}: {r.stderr.strip()}"
        return out if out else "(empty output)"
    except subprocess.TimeoutExpired:
        return "ERROR: timed out (120s)"
    except Exception as e:
        return f"ERROR: {e}"


TOOL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "run_git",
        "description": (
            "Run any git command in the repository. "
            "Pass the command WITHOUT the leading 'git'. "
            "Examples: 'show abc123', 'blame abc123~1 -- path/to/file', "
            "'log -Ssome_func -n20 --format=%H %s', "
            "'log -L:func_name:path/file.c', "
            "'grep -n pattern abc123 -- path/'."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "Git command arguments (without 'git' prefix)",
                },
            },
            "required": ["command"],
        },
    },
}
