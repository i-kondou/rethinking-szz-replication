"""
git_grep tool for AgentSZZ
============================
Search for a string in the codebase at a specific commit snapshot.
Useful for understanding call relationships, finding function definitions,
and locating all references to a symbol.
"""

import subprocess
from typing import Optional


def _run_git(args: list[str], repo_path: str, max_output_lines: int = 100) -> str:
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=30,
        )
        # git grep returns 1 when no matches found (not an error)
        if result.returncode == 1 and not result.stderr.strip():
            return ""
        if result.returncode not in (0, 1):
            return f"ERROR: {result.stderr.strip()}"

        lines = result.stdout.strip().split("\n")
        if len(lines) > max_output_lines:
            truncated = lines[:max_output_lines]
            truncated.append(f"\n... [truncated: {max_output_lines}/{len(lines)} lines]")
            return "\n".join(truncated)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        return "ERROR: command timed out (30s)"
    except Exception as e:
        return f"ERROR: {str(e)}"


def git_grep(
    search_string: str,
    repo_path: str,
    commit: str = "HEAD",
    path: Optional[str] = None,
    show_line_numbers: bool = True,
) -> str:
    """
    Search for a string in the codebase at a specific commit.
    Use to find function definitions, call sites, and symbol references.

    Args:
        search_string:    String to search for.
        repo_path:        Path to the git repository.
        commit:           Search at this commit (default HEAD).
        path:             Optional path filter (e.g., "drivers/gpu/").
        show_line_numbers: Show line numbers in output (default True).
    """
    args = ["grep"]

    if show_line_numbers:
        args += ["-n"]

    args += [search_string, commit]

    if path:
        args += ["--", path]

    raw = _run_git(args, repo_path)

    if not raw:
        return f"No matches found for '{search_string}' at {commit}"

    if raw.startswith("ERROR:"):
        return raw

    # Strip the commit prefix from each line for cleaner output
    # git grep outputs: commit:file:line:content -> file:line:content
    lines = raw.split("\n")
    cleaned = []
    prefix = f"{commit}:"
    for line in lines:
        if line.startswith(prefix):
            cleaned.append(line[len(prefix):])
        else:
            cleaned.append(line)

    return "\n".join(cleaned)


# Tool schema for LLM function calling
TOOL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "git_grep",
        "description": (
            "Search for a string in the codebase at a specific commit. "
            "Use to find function definitions, call sites, symbol references, "
            "and understand code relationships. Unlike git_log_s which searches "
            "history, git_grep searches a single snapshot of the codebase."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "search_string": {
                    "type": "string",
                    "description": "String to search for (function name, variable, macro, etc.)",
                },
                "commit": {
                    "type": "string",
                    "description": "Search at this commit (default HEAD)",
                    "default": "HEAD",
                },
                "path": {
                    "type": "string",
                    "description": "Optional path filter (e.g., 'drivers/gpu/')",
                },
            },
            "required": ["search_string"],
        },
    },
}


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="git grep tool for AgentSZZ")
    parser.add_argument("repo_path", help="Path to git repository")
    parser.add_argument("search_string", help="String to search for")
    parser.add_argument("--commit", default="HEAD", help="Search at this commit (default HEAD)")
    parser.add_argument("--path", default=None, help="Optional path filter")

    args = parser.parse_args()
    print(git_grep(args.search_string, args.repo_path, args.commit, args.path))