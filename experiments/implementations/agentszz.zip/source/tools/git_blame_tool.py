"""
git_blame tool for AgentSZZ
===========================
Blame a file at a given commit to find which commit last modified each line.
Single-file only. Parses porcelain output into a readable summary.
"""

import subprocess
import re
from typing import Optional


def _run_git(args: list[str], repo_path: str, max_output_lines: int = 200) -> str:
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            return f"ERROR: {result.stderr.strip()}"

        lines = result.stdout.strip().split("\n")
        if len(lines) > max_output_lines:
            truncated = lines[:max_output_lines]
            truncated.append(f"\n... [truncated: {max_output_lines}/{len(lines)} lines]")
            return "\n".join(truncated)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        return "ERROR: command timed out (30s)"
    except Exception as e:
        return f"ERROR: {str(e)}"


def _parse_blame_porcelain(raw: str) -> str:
    """Parse git blame --porcelain output into a readable summary."""
    results = []
    current_hash = None
    current_line = None
    summary = None
    seen_commits = {}

    for line in raw.split("\n"):
        if re.match(r"^[0-9a-f]{40}\s", line):
            parts = line.split()
            current_hash = parts[0]
            current_line = parts[2] if len(parts) >= 3 else "?"
            summary = None
        elif line.startswith("summary "):
            summary = line[len("summary "):]
        elif line.startswith("\t"):
            code = line[1:]
            short_hash = current_hash[:12] if current_hash else "?"

            if current_hash and current_hash not in seen_commits:
                seen_commits[current_hash] = summary or "(no summary)"

            results.append(f"L{current_line}: {short_hash} | {code}")

    output = "\n".join(results)
    if seen_commits:
        legend = "\n\nCommits referenced:\n"
        for h, s in seen_commits.items():
            legend += f"  {h[:12]}  {s}\n"
        output += legend

    return output


def git_blame(
    file_path: str,
    repo_path: str,
    commit: str = "HEAD",
    line_start: Optional[int] = None,
    line_end: Optional[int] = None,
) -> str:
    """
    Blame a file at a given commit to find which commit last modified each line.

    Args:
        file_path:  Path to file relative to repo root.
        repo_path:  Path to the git repository.
        commit:     Commit at which to blame (default HEAD).
        line_start: Start line number (1-indexed, optional).
        line_end:   End line number (inclusive, optional).
    """
    args = ["blame", "--porcelain"]

    if line_start and line_end:
        args += [f"-L{line_start},{line_end}"]
    elif line_start:
        args += [f"-L{line_start},{line_start}"]

    args += [commit, "--", file_path]

    raw = _run_git(args, repo_path)
    if raw.startswith("ERROR:"):
        return raw

    return _parse_blame_porcelain(raw)


# Tool schema for LLM function calling
TOOL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "git_blame",
        "description": (
            "Blame a file at a given commit to find which commit last "
            "modified each line. Single-file only — use git_log_s for "
            "cross-file tracking."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "File path relative to repo root",
                },
                "commit": {
                    "type": "string",
                    "description": "Blame at this commit (default HEAD)",
                    "default": "HEAD",
                },
                "line_start": {
                    "type": "integer",
                    "description": "Start line number (1-indexed)",
                },
                "line_end": {
                    "type": "integer",
                    "description": "End line number (inclusive)",
                },
            },
            "required": ["file_path"],
        },
    },
}


if __name__ == "__main__":
    import sys

    if len(sys.argv) < 4:
        print("Usage: python git_blame_tool.py <repo_path> <commit> <file_path> [line_start] [line_end]")
        print("Example: python git_blame_tool.py ../../repo/linux af1e0a7d39f9~1 drivers/firmware/microchip/mpfs-auto-update.c 387 387")
        sys.exit(1)

    repo = sys.argv[1]
    commit = sys.argv[2]
    file_path = sys.argv[3]
    line_start = int(sys.argv[4]) if len(sys.argv) > 4 else None
    line_end = int(sys.argv[5]) if len(sys.argv) > 5 else None

    print(git_blame(file_path, repo, commit, line_start, line_end))