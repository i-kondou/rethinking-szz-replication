"""
git_log_s tool for AgentSZZ
============================
Search for commits that added or removed a string (git log -S).
Works across ALL files — primary tool for cross-file tracking.
"""

import subprocess
import re
from typing import Optional


TRAILER_PATTERN = re.compile(
    r"^\s*("
    r"Signed-off-by|Fixes|Reported-by|Reviewed-by|Acked-by|"
    r"Cc|Link|Closes|Tested-by|Co-developed-by|Suggested-by|"
    r"Reported-and-tested-by|Reviewed-and-tested-by|"
    r"Author|Message-Id|Message-ID"
    r"):\s.*$",
    re.MULTILINE,
)


def _run_git(args: list[str], repo_path: str, max_output_lines: int = 200) -> str:
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=60,  # -S can be slow on large repos
        )
        if result.returncode != 0:
            return f"ERROR: {result.stderr.strip()}"

        lines = result.stdout.strip().split("\n")
        if len(lines) > max_output_lines:
            truncated = lines[:max_output_lines]
            truncated.append(f"\n... [truncated: {max_output_lines}/{len(lines)} lines]")
            return "\n".join(truncated)
        return result.stdout.strip()
    except subprocess.TimeoutExpired:
        return "ERROR: command timed out (60s)"
    except Exception as e:
        return f"ERROR: {str(e)}"


def _filter_trailers(text: str) -> str:
    text = TRAILER_PATTERN.sub("", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def git_log_s(
    search_string: str,
    repo_path: str,
    path: Optional[str] = None,
    after: Optional[str] = None,
    before: Optional[str] = None,
    max_commits: int = 20,
) -> str:
    """
    Search for commits that added or removed a string (git log -S).
    Works across ALL files — primary tool for cross-file tracking.

    Args:
        search_string: String to search for (function name, variable, etc.).
        repo_path:     Path to the git repository.
        path:          Optional path filter (e.g., "drivers/net/").
        after:         Only commits after this date (e.g., "2022-09-01").
        before:        Only commits before this date (e.g., "2023-12-01").
        max_commits:   Max number of commits to return (default 20).
    """
    args = [
        "log",
        f"-S{search_string}",
        f"-n{max_commits}",
        "--format=commit %H%nDate: %ad%n%n    %s%n",
        "--date=format:%a %b %d %H:%M:%S %Y %z",
    ]

    if after:
        args += [f"--after={after}"]
    if before:
        args += [f"--before={before}"]

    if path:
        args += ["--", path]

    raw = _run_git(args, repo_path)
    if raw.startswith("ERROR:"):
        return raw

    if not raw.strip():
        return f"No commits found that add or remove '{search_string}'"

    return _filter_trailers(raw)


# Tool schema for LLM function calling
TOOL_SCHEMA = {
    "type": "function",
    "function": {
        "name": "git_log_s",
        "description": (
            "Search commits that added or removed a string (git log -S). "
            "Works across ALL files — primary tool for cross-file and "
            "refactor/rename tracking."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "search_string": {
                    "type": "string",
                    "description": "String to search (function name, variable, macro, etc.)",
                },
                "path": {
                    "type": "string",
                    "description": "Optional path filter (e.g., 'drivers/net/')",
                },
                "after": {
                    "type": "string",
                    "description": "Only commits after this date (e.g., '2022-09-01')",
                },
                "before": {
                    "type": "string",
                    "description": "Only commits before this date (e.g., '2023-12-01')",
                },
                "max_commits": {
                    "type": "integer",
                    "description": "Max commits to return (default 20)",
                    "default": 20,
                },
            },
            "required": ["search_string"],
        },
    },
}


if __name__ == "__main__":
    import sys
    import argparse

    parser = argparse.ArgumentParser(description="git log -S tool for AgentSZZ")
    parser.add_argument("repo_path", help="Path to git repository")
    parser.add_argument("search_string", help="String to search for")
    parser.add_argument("path", nargs="?", default=None, help="Optional path filter")
    parser.add_argument("--after", default=None, help="Only commits after date (e.g., 2022-09-01)")
    parser.add_argument("--before", default=None, help="Only commits before date (e.g., 2023-12-01)")
    parser.add_argument("-n", "--max-commits", type=int, default=20, help="Max commits (default 20)")

    args = parser.parse_args()
    print(git_log_s(args.search_string, args.repo_path, args.path, args.after, args.before, args.max_commits))